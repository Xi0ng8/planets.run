globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/_t-p3jItaI-3fj7guTrLT/_buildManifest.js",
    "static/_t-p3jItaI-3fj7guTrLT/_ssgManifest.js",
    "static/_t-p3jItaI-3fj7guTrLT/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/13bq96162av1i.js",
    "static/chunks/0c-2ktq6kuid-.js",
    "static/chunks/0x9a4~fyy7sts.js",
    "static/chunks/0.79dbd9bldv9.js",
    "static/chunks/06l~fw5wtx-y4.js",
    "static/chunks/0j7b~opwgavth.js",
    "static/chunks/turbopack-0w1jr.rxpvqa3.js"
  ]
};
