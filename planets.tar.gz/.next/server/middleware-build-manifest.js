globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/BTTu3oHfQ5U2N_tvfZ_tL/_buildManifest.js",
    "static/BTTu3oHfQ5U2N_tvfZ_tL/_ssgManifest.js",
    "static/BTTu3oHfQ5U2N_tvfZ_tL/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/0gz6pbnqr6uxn.js",
    "static/chunks/0ipef2sa~ztmk.js",
    "static/chunks/110q6k5sdl4es.js",
    "static/chunks/07uz2g0_38qia.js",
    "static/chunks/0o59ac8426icc.js",
    "static/chunks/turbopack-0u36jp-61jd02.js"
  ]
};
