globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/MP75LJax0H57Yo1NuaiB6/_buildManifest.js",
    "static/MP75LJax0H57Yo1NuaiB6/_ssgManifest.js",
    "static/MP75LJax0H57Yo1NuaiB6/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/0gz6pbnqr6uxn.js",
    "static/chunks/0ipef2sa~ztmk.js",
    "static/chunks/110q6k5sdl4es.js",
    "static/chunks/07uz2g0_38qia.js",
    "static/chunks/0o59ac8426icc.js",
    "static/chunks/turbopack-0u36jp-61jd02.js"
  ]
};
