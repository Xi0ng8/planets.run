module.exports=[9475,a=>{"use strict";var b=a.i(87924),c=a.i(46271);a.s(["default",0,function({children:a}){return(0,b.jsx)(c.motion.div,{initial:{opacity:0,scale:.95,filter:"blur(10px)"},animate:{opacity:1,scale:1,filter:"blur(0px)"},transition:{duration:.8,ease:"easeOut"},className:"w-full h-full",children:a})}])}];

//# sourceMappingURL=src_app_template_tsx_0a0as.h._.js.map