module.exports=[76041,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_brucetrail_page_actions_0ho.dc3.js.map