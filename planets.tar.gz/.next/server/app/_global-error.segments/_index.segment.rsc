1:"$Sreact.fragment"
2:I[57317,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js"],"default"]
3:I[20874,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"_t-p3jItaI-3fj7guTrLT"}
