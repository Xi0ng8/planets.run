1:"$Sreact.fragment"
2:I[37367,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js"],"ViewportBoundary"]
3:I[37367,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[15551,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Planets.Run | Global Running Odyssey"}],["$","meta","1",{"name":"description","content":"Cross-planet running and exploration tracking brand."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0025vefy1r7ti.ico","sizes":"640x640","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"_t-p3jItaI-3fj7guTrLT"}
