1:"$Sreact.fragment"
2:I[83710,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/14wi9h97y0.nr.js","/_next/static/chunks/17en4pwu0aybq.js"],"default"]
3:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"w-screen h-screen relative bg-black overflow-hidden","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/14wi9h97y0.nr.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/17en4pwu0aybq.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"MP75LJax0H57Yo1NuaiB6"}
5:null
