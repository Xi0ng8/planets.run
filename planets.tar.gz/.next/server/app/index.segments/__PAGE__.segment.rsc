1:"$Sreact.fragment"
2:I[35479,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js","/_next/static/chunks/15v4ji3ylxc-b.js","/_next/static/chunks/0s_w407.d1bdf.js"],"default"]
3:I[37367,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"w-screen h-screen relative bg-black overflow-hidden","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/15v4ji3ylxc-b.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0s_w407.d1bdf.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"_t-p3jItaI-3fj7guTrLT"}
5:null
