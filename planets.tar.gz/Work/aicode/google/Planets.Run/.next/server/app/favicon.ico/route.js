var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0sqmaqd._.js")
R.c("server/chunks/[root-of-the-server]__0.ozhcs._.js")
R.c("server/chunks/0lrb_google_Planets_Run__next-internal_server_app_favicon_ico_route_actions_0oka.b-.js")
R.m(73479)
module.exports=R.m(73479).exports
