1:"$Sreact.fragment"
2:I[35479,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js","/_next/static/chunks/0v8-z4592dsrt.js"],"default"]
3:I[37367,["/_next/static/chunks/130k9ut561a60.js","/_next/static/chunks/0_k1dyscgt2ik.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"w-screen h-screen relative bg-black overflow-hidden","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/0v8-z4592dsrt.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"wHlb-VWHHvNMtHRI2_Lsz"}
5:null
