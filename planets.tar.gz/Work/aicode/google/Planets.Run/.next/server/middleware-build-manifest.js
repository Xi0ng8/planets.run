globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/wHlb-VWHHvNMtHRI2_Lsz/_buildManifest.js",
    "static/wHlb-VWHHvNMtHRI2_Lsz/_ssgManifest.js",
    "static/wHlb-VWHHvNMtHRI2_Lsz/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/13bq96162av1i.js",
    "static/chunks/0jlhf-4ls1~us.js",
    "static/chunks/0br-roci3s.85.js",
    "static/chunks/0.79dbd9bldv9.js",
    "static/chunks/0h_in1mll4vfs.js",
    "static/chunks/12j-xbx018vzg.js",
    "static/chunks/turbopack-0o66mo5ah2cji.js"
  ]
};
